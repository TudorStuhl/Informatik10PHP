# Informatik10PHP

What you need to know:
* access to .json files needs to be turned of on the webserver otherwise the database_config will be visible to everyone
